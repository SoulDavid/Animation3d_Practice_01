#include "Rigid_Platform.hpp"

namespace Engine
{
	Rigid_Platform::Rigid_Platform(Render_Task& tr, float large, float height, b2World physic_world)
	{

	}
}
